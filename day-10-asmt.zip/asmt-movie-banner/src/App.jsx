import MovieBanner from "./components/MovBan";

function App() {
  return <MovieBanner />;
}

export default App;
