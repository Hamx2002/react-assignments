export default function Amenity5() {
  return (
    <section style={{ padding: "16px" }}>
      <h2>Security</h2>
      <p>Peacekeeping teams ensure safety and harmony for all citizens.</p>
      <hr />
    </section>
  );
}
