export default function Amenity2() {
  return (
    <section style={{ padding: "16px" }}>
      <h2>Education</h2>
      <p>Equal and high-quality education for all species.</p>
      <hr />
    </section>
  );
}
