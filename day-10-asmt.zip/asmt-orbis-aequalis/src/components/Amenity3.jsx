export default function Amenity3() {
  return (
    <section style={{ padding: "16px" }}>
      <h2>Transport</h2>
      <p>Free and clean transport available across the planet.</p>
      <hr />
    </section>
  );
}
