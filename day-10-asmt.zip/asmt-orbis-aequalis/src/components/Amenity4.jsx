export default function Amenity4() {
  return (
    <section style={{ padding: "16px" }}>
      <h2>Housing</h2>
      <p>Every resident is provided with safe and comfortable housing.</p>
      <hr />
    </section>
  );
}
