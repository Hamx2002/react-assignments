export default function Amenity1() {
  return (
    <section style={{ padding: "16px" }}>
      <h2>Medical Care</h2>
      <p>Free healthcare available to all residents.</p>
      <hr />
    </section>
  );
}
