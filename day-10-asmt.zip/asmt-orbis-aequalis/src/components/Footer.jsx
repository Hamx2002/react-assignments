export default function Footer() {
  return (
    <footer style={{ textAlign: "center", marginTop: "24px", padding: "12px" }}>
      <hr />
      <p>© 2024 Orbis Aequalis</p>
    </footer>
  );
}
